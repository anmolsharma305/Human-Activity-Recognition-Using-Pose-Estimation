
Sitting - v6 sitting
==============================

This dataset was exported via roboflow.ai on June 7, 2021 at 7:34 PM GMT

It includes 26 images.
S are annotated in Tensorflow Object Detection format.

The following pre-processing was applied to each image:
* Resize to 416x416 (Fit within)

No image augmentation techniques were applied.


